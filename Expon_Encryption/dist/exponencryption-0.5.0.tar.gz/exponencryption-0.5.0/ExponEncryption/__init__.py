"""
ExponEncryption - A Python library for secure string encryption
"""

from .encryption_V2 import Encrytion

__version__ = "0.5.0"
__author__ = "Eason Ma"

__all__ = ["Encrytion"]
