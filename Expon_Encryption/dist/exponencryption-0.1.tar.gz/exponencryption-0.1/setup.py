from setuptools import find_packages, setup

setup(
    name='ExponEncryption',
    version='0.1',
    description='A simple Python library for Encrypting string.',
    author='Eason Ma',
    packages=find_packages()
)