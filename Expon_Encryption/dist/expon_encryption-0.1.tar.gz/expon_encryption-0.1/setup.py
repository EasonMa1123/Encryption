from setuptools import find_packages, setup

setup(
    name='Expon_Encryption',
    version='0.1',
    description='A simple Python library for calculating the area of geometric shapes.',
    author='Eason Ma',
    packages=find_packages()
)